<?php require("header.php") ?>

	<section class="cd-hero">
		<ul class="cd-hero-slider autoplay">
			<!--<li class="selected">
				<div class="cd-full-width" style="background-color: #fff; color:#000;">
					<h2>Hero slider</h2>
					<p>A simple, responsive slideshow in CSS &amp; jQuery.</p>
					<a href="http://codyhouse.co/?p=675" class="cd-btn">Article &amp; Download</a>
				</div> <!-- .cd-full-width --
			</li>-->
			<?php
			$banner = $this->db->query("SELECT * FROM ss_banner WHERE publish = '1'");
			$x = 1;
			foreach ($banner->result_array() as $key => $value) {
				if($x == 1){
					$sel = 'class="selected"';
				} else {
					$sel = '';
				}
			?>
			<li <?php echo $sel ?> >
				<div class="cd-half-width">
					<!--<h2>Slide title here</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. In consequatur cumque natus!</p>-->
					<?php echo $value['keterangan'] ?>
					<a href="<?php echo $value['link'] ?>" class="cd-btn">Learn More</a>
				</div> <!-- .cd-half-width -->

				<div class="cd-half-width cd-img-container">
					<img src="<?php echo base_url() . 'uploads/banner/' . $value['foto'] ?>" alt="<?php echo $value['judul'] ?>">
				</div> <!-- .cd-half-width.cd-img-container -->
			</li>
			<?php $x++; } ?>
				</div> <!-- .cd-bg-video-wrapper --

		</ul> <!-- .cd-hero-slider -->

		<div class="cd-slider-nav" >
			<nav>
				<span class="cd-marker item-1"></span>
				
				<ul>
					<?php
					$ling = $this->db->query("SELECT * FROM ss_banner WHERE publish = '1'");
					$i =1;
					foreach ($ling->result_array() as $key => $val) {
						if($i == 1){
							//echo '<li class="selected"><a href="'.$val['link'].'">'.$val['judul'].'</a></li>';
							echo '<li class="selected"><a href="'.$val['link'].'"></a></li>';
						} else {
							//echo '<li><a href="'.$val['link'].'">'.$val['judul'].'</a></li>';
							echo '<li><a href="'.$val['link'].'"></a></li>';
						} 
						$i++;
					}
					?>
				</ul>
			</nav> 
		</div> <!-- .cd-slider-nav -->
	</section> <!-- .cd-hero -->
	<main class="cd-main-content" style="font-size: 9px">
		<div class="col-md-12">
			<?php echo $mainpageContent ?>
		</div>
	</main> <!-- .cd-main-content -->
	<?php require("footer.php") ?>