<?php require("header.php"); ?>
<br><br><br>
<div class="col-md-12">
	<div class="panel panel-default">
		<div class="panel-heading"><h3>Oops! Halaman tidak ditemukan.</h3></div>
		<div class="panel-body">
		<p>
            We could not find the page you were looking for.
            Meanwhile, you may <a href='<?php echo base_url() ?>'>return to home</a> or try using the search form.
        </p>
		</div>
		<br><br>
	</div>
</div>
</div>
<?php require("footer.php"); ?>