<div class="clearfix"></div>
	<br><br><br>
	<div class="containercc">
	<div class="footer">
		
		<div class="col-md-2"></div>
		<div class="col-md-8"> 
			<div class="pull-right"> 
				<ul>
				<?php
				$page = $this->db->query("SELECT * FROM cm_post WHERE post_type = 'page' AND publish = '1' AND post_title NOT IN ('main Page')");
				foreach ($page->result_array() as $key => $value) {
					# code...
					echo '<li><a href="'.base_url() .'page/view/'.$value['id'].'" >'.$value['post_title'].'</a></li>';
				}
				?>
				</ul>
			</div>
			<div class="clearfix"></div>
			<hr>
			Copyright &copy; 2016 VICTORYVII All rights reserved.
		</div>
		<div class="col-md-2"></div>
		<div class="clearfix"></div>
	</div>
	</div>
</div>
</body>
</html>