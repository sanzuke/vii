<?php require("header.php") ?>
	<br><br><br>
	<div class="row">
		<ol class="breadcrumb">
		  <li><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i></a></li>
		  <li><a href="#">Kategori</a></li>
		  <li class="active">Sepatu</li>
		</ol>
	</div>
	<br>
		<hr class="featurette-divider">
		<?php $i=1; foreach ($listlastproducts as $key => $value) { $pht = explode(".",$value['photo']) ?>
		<?php if($i % 2){ $pos = 'pull-right'; } else { $pos = 'pull-left'; } ?>
		<div class="featurette" id="about">
            <img class="featurette-image img-responsive <?php echo $pos; ?>" src="<?php echo base_url().'uploads/thumb/'.$pht[0]."_thumb.".$pht[1]; ?>">
            <h2 class="featurette-heading"><?php echo $value['productname']  ?>
                <!-- <span class="text-muted">Will Catch Your Eye</span>-->
            </h2>
            <p class="lead"><?php echo $value['description']  ?></p>
            <div class="btn-group">
					<a href="<?php echo base_url().'index.php/product/view/'.$value['productcode'].'/'. str_replace(" ","-", strtolower($value['productname'])).'.html' ?>" class="btn btn-default" type="button"  > <i class="fa fa-file"></i> Learn More </a>
					<button class="btn btn-primary" type="button" onclick="addtocart('<?php echo $value['productcode'] ?>','<?php echo $value['productname'] ?>','<?php echo $value['sale'] ?>')" > Buy <i class="fa fa-shopping-cart"></i></button>
				</div>
        </div>
        <hr class="featurette-divider">
        <?php $i++; } ?>
		
	</div>
	<script type="text/javascript">
        function addtocart(pc,pn,pr){
            var qty = 1;//$("#qty").val();
            var cl = $("#color").val();
            var sz = $("#size").val();
            $.post("<?php echo base_url() ?>cart/add", {product_id: pc, pn:pn, quantity :qty, pr:pr, size :sz, color:cl}, function(feedback){
                window.location.reload();
            })
        }
    </script>
<?php require("footer.php") ?>