<div class="form-group">
	<label>Password Lama</label>
	<input type="text" name="username" id="username" class="form-control" required="required">
</div>
<div class="form-group">
	<label>Password Baru</label>
	<input type="Password" name="password" id="password" class="form-control" required="required">
</div>
<div class="form-group">
	<label>Password Lagi</label>
	<input type="Password" name="password2" id="password2" class="form-control" required="required">
</div>
<div class="form-group">
	<button class="btn btn-default"><i class="fa fa-save"></i> Simpan</button>
</div>